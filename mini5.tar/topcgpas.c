#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*
Program to generate a report on the students having the top CGPAs
*****************************************************************
* Author	Dept.	  Date		  Notes
*****************************************************************
* Mila R	ECON	  April 3 2021    Initial Version.
* Mila R	ECON	  April 4 2021	  Error Handeling.
* Mila R 	ECON	  April 5 2021    Error Handeling.
* Mila R	ECON	  April 6 2021    Implement struct.
* Mila R	ECON	  April 7 2021	  Add additional functions.
* Mila R	ECON	  April 8 2021    Forming linked list.
* Mila R	ECON	  April 9 2021    Forming linked list.
* Mila R	ECON	  April 10 2021   Forming linked list.
* Mila R	ECON	  April 11 2021   Set up output file.
* Mila R.	ECON	  April 12 2021   Freeing memory.
* Mila R	ECON      April 13 2021   Error handeling.
* Mila R	Econ	  April 14 2021   Error handeling.
*/

//define node structure for each student record
struct StudentRecord {

	//define all the attributes/fields
	long sid;
	char email[30];
	char lname[20];
	char fname[20];
	float cgpa;
	struct StudentRecord *next;
};

//set up a function to add a node in front of inputed node
void addNodeFront(struct StudentRecord* head, struct StudentRecord* newnode){
	//point the next part to the head
	newnode->next=head;
	//set the head to the new node
	head=newnode;
}

//set up a function to add a node after a certain node
void addNodeBack(struct StudentRecord* head, struct StudentRecord* newnode){
        //set the next part of the node to the next of the head
	newnode->next=head->next;
	//set the next node from the head to the new node
	head->next=newnode;
}

//set up a main function
int main(int argc, char *argv[]){
	
	//check if there are two arguments (1.6)
        if( argc != 3 ){
                printf("Usage ./topcgpas <sourcecsv> <outputcsv>\n");
                return 1;
        }

	//open the file
	FILE *input_file= fopen(argv[1], "rt");

	//check if the file can be read (1.7)
	if (input_file==NULL){
		printf("Error! Unable to open the input file %s\n",argv[1]);
		return 1;
	}
		
	//set a char array to a large arbitrary value that has the correct size to hold each line of the file
	char line[100];
	//count the number of lines
	int numOfLines=0;
	//make a pointer to a node
	struct StudentRecord *head;
	//make it a dynamic structure
	head= (struct StudentRecord*)malloc(sizeof(struct StudentRecord));
	
	//set up another node pointer
        struct StudentRecord *temp;
        //set up the dynamic memory
	temp= (struct StudentRecord*)malloc(sizeof(struct StudentRecord));
	
	//iterate through all the lines of the file
	while (fgets(line, sizeof(line), input_file)){
		//form a pointer to a node
        	struct StudentRecord *current;
        	//make it a dynamic structure
        	current= (struct StudentRecord*)malloc(sizeof(struct StudentRecord));	
		//for the first line of data, set it to the head pointer
		if (numOfLines==1){
                         //set the sid attribute
                        char * s2 =",";
                        char *field=strtok(line, s2);
                        head->sid=atol(field);

                        //add the email attribute
                        strcpy(head->email,strtok(NULL,s2));

                        //add to the lname attribute
                        strcpy(head->lname,strtok(NULL,s2));

                        //add to the fname attribute
                        strcpy(head->fname,strtok(NULL,s2));

                        //add to the cgpa attribute
                        char *cgpa=strtok(NULL,s2);
                        head->cgpa=atof(cgpa);
		}
		//for every line of data after set it to the current pointer
		if (numOfLines>1){
			 //set the sid attribute
                        char * s2 =",";
                        char *field=strtok(line, s2);
                        current->sid=atol(field);

                        //add the email attribute
                        strcpy(current->email,strtok(NULL,s2));

                        //add to the lname attribute
                        strcpy(current->lname,strtok(NULL,s2));

                        //add to the fname attribute
                        strcpy(current->fname,strtok(NULL,s2));

                        //add to the cgpa attribute
                        char *cgpa=strtok(NULL,s2);
                        current->cgpa=atof(cgpa);
		}

		//set the temp to the head
		temp=head;
		//set a variable to count the iterations
		int count=0;
		//iterate through the linked list
		while(temp!=NULL){
			//check if the current pointer node cgpa is greater than the head in the linked list 
			if (current->cgpa >= temp->cgpa && count==0){
				//set the next for the current to the head
				current->next=head;
				//make current the new head
				head=current;
				//get out of the while loop
				break;
			}
  			//check if the current nodes cgpa is less than the temp cgpa but greater than the next nodes cgpa
			if(current->cgpa <= temp->cgpa && current->cgpa >= temp->next->cgpa){
				//add the current node behind temp
                                addNodeBack(temp,current);
				//get out of while loop
                                break;
                        }
			//add to the count of lines
			count++;
			//move to the next node in linked list
			temp=temp->next;

		}
		//add to the number of lines
		numOfLines++;

		//check to make sure that current (malloc) never runs out of memory (1.16)
		if (current==NULL){
                	printf("Error! program ran out of memory.");
                	return 1;
		}
		
		//set current to an arbitrary value (don't make it point to a node in the linked list because need it later on)
		current=NULL;
		//free the pointer (1.21)
		free(current);
		
	}

	//check for invalid inputs (1.12)
	//check if there is only a header in the csv file (1.8)
	if (numOfLines==1){
		//display an error message and terminate
		printf("Error! Input CSV file %s is empty\n",argv[1]);
                return 1;
	}
	//check if file is empty (1.9)
	if (numOfLines==0){
		//display an error message and terminate
		printf("Error! Input CSV file %s is empty\n", argv[1]);
                return 1;
	}

	//close the input file
	fclose(input_file);

	//set a pointer and open up output file
	FILE *output_file;
	output_file=fopen(argv[2], "w+");
	
	//check that the output file can be open and written in (1.11)
	if (output_file==NULL){
                printf("Error! Unable to open the output file %s\n",argv[2]);
                return 1;
        }

	//write to the output file (1.10)
	
	//write the header into the output file 
	fprintf(output_file,"sid,email,cgpa\n");
	
	//set a variable equal to the number of lines
	int iterations=numOfLines;	
	
	//check if the number of lines is greater than 5
	if(numOfLines>=6){
		//since more lines than 5 set it to 5 lines
		numOfLines=5;
	}
	else{
		//set number of lines to the length -1 to not include the header
		numOfLines=numOfLines-1;
	}
	//set the pointer to the head
	temp=head;
	//set another pointer for the fith node
	struct StudentRecord *lastelement;
	//set up a dynamic memory
	lastelement= (struct StudentRecord*)malloc(sizeof(struct StudentRecord));
	//set an integer to 0 to count iterations
	int count2=0;

	//iterate through all the lines
	while(temp!=NULL){

		//set the element pointer to the 5th element
		if (count2==4){
			lastelement=temp;
		}
		//check if a nodes cgpa is the same as the 5th elements cgpa and is greater than the 5th element
		if (temp->cgpa == lastelement->cgpa && count2>4){
			//add to the numOfLines printed
			numOfLines=numOfLines+1;
		}
		//check if at the end of the linked list
		if (count2+1==iterations){
                        break;
                }
		//add to the count variable for each iteration
		count2++;
		//move to the next node in the list
		temp=temp->next;
	}

	//check if the last element (malloc) in the node ran out of memory (1.16)
	if (lastelement ==NULL){
                printf("Error! program ran out of memory");
                return 1;
        }

	//set the last element to an arbitary value (NULL) so it doesn't point to linked list
	lastelement=NULL;
        //free the poiner to the last element (1.21)
        free(lastelement);

	//reset temp variable to the head
        temp=head;
	//set a variable for the count of iterations
	int count=0;
	//iterate through the linked list till the proper number of nodes are reached
        while(temp !=NULL && count < numOfLines){
		
		//add to the output file the sid,email,and cgpa of each student (1.10)
		fprintf(output_file,"%ld,%s,%.1f\n",temp->sid,temp->email,temp->cgpa);
		//move to next node
                temp=temp->next;
		//add to the count variable
                count++;
        }
	//check if temp (malloc) has ran out of memory (1.16)
	if (temp==NULL){
                ("Error! program ran out of memory");
                return 1;
        }
	//check if head (malloc) has run out of memory (1.16)
        if (head==NULL){
                printf("Error! program ran out of memory.");
                return 1;
        }

	//set temp variable to arbitary value (NULL)
	temp=NULL;
	//free the pointer (1.21)
	free(temp);
	
	//free head pointer that points to the linked list (1.21)
	free(head);
	
	//close the output file
	fclose(output_file);

}
